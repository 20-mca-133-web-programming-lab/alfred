<!DOCTYPE html>
<html>
<body>
<?php
$students = array("shifna","noora","veena","nidha");
echo'Asort';
echo'<br>';
asort($students);
print_r($students);
echo '<br>';
echo 'Arsort';
echo '<br>';
arsort($students);
print_r($students);
?>
</body>
</html>

